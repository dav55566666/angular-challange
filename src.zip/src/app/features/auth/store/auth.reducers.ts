import { createReducer, on, Store } from "@ngrx/store";
import { authInitialState } from "./auth.state";
import { AuthActions } from "./auth.actions";
import { selectUsers, UserType } from "../../users";
import { inject } from "@angular/core";

export const authReducers = createReducer(
    authInitialState,
    on(AuthActions.registrationUser, (state, { user }) => ({
        ...state,
        ...user
    })),
    on(AuthActions.login, (state, { user }) => {
        const usersData: UserType[] = selectUsers(inject(Store));
        const loginedUser: UserType | null = usersData.find(el => el.username === user.username && el.password === user.password) || null
        return {
            ...state,
            currentUser: loginedUser
        }
    }),
    on(AuthActions.logout, (state) => ({
        ...state,
        currentUser: null
    }))
)