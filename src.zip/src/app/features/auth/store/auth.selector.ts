import { authFeature } from "./auth.state";

export const selectCurrentUser = authFeature.selectCurrentUser