import { Component } from '@angular/core';

@Component({
  selector: 'registartion-page-component',
  standalone: false,
  templateUrl: './registartion-page-component.component.html',
  styleUrl: './registartion-page-component.component.scss'
})

export class RegistartionPageComponent {

};
