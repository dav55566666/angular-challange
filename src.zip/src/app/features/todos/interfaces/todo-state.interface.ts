import { TodoItemType } from "./todo-item.interface";

export interface ToDoState  {
    todos: TodoItemType[]
}