import { todoFeature } from "./todo.state";

export const selectTodos = todoFeature.selectTodos