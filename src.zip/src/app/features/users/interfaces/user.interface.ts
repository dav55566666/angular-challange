export interface UserType {
    id: number;
    username: string;
    password: string;
}