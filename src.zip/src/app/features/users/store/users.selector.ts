import { usersFeature } from "./users.state";

export const selectUsers = usersFeature.selectUsers