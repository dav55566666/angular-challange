import { Routes } from '@angular/router';
import { LoginPageComponent, RegistartionPageComponent, TodosCreateComponent, TodosListComponent } from './features';
import { AuthGuard } from './common';

export const routes: Routes = [
    {
        path: 'todo/list',
        component: TodosListComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'todo/create',
        component: TodosCreateComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'auth/login',
        component: LoginPageComponent
    },
    {
        path: 'auth/registration',
        component: RegistartionPageComponent
    }
];
