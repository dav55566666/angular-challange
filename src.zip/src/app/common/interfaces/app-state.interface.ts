import { ToDoState } from "../../features";

export interface AppState {
    todos: ToDoState
}