export enum ValidationTypes {
    EMAIL = 'email',
    PASSWORD = 'password',
    PHONE = 'phone'
}