import { FormComponent } from './component/form.component';
import { NgModule } from "@angular/core";

@NgModule({
    imports: [],
    exports: [FormComponent],
    declarations: [FormComponent]
})

export class FormModule {}