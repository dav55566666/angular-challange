export enum ButtonInputType {
    BUTTON = 'button',
    SUBMIT = 'submit',
}