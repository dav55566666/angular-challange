import { NgModule } from "@angular/core";
import { ButtonInputComponent } from "./component";

@NgModule({
    imports: [],
    exports: [ButtonInputComponent],
    declarations: [ButtonInputComponent]
})

export class ButtonInputModule {}